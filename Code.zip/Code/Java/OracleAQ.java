package com.pwc.cm.agent.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;

import oracle.AQ.AQQueueTable;
import oracle.AQ.AQQueueTableProperty;

import oracle.jms.AQjmsAgent;
import oracle.jms.AQjmsConnection;
import oracle.jms.AQjmsDestination;
import oracle.jms.AQjmsDestinationProperty;
import oracle.jms.AQjmsFactory;
import oracle.jms.AQjmsSession;
import oracle.jms.AQjmsTextMessage;
import oracle.jms.AQjmsTopicConnectionFactory;
import oracle.jms.AQjmsTopicPublisher;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class OracleAQ {
    static String hostname = "cloudmove.mypwc.in";
    static String oracleService = "xepdb1";
    static int portno = 1527;
    static String userName = "cms";
    static String password = "oracle";
    static String driver = "thin";

    public static QueueConnection getConnection() {
        QueueConnectionFactory QFac = null;
        QueueConnection QCon = null;
        try {
            // get connection factory , not going through JNDI here
            QFac = AQjmsFactory.getQueueConnectionFactory(hostname, oracleService, portno, driver);
            // create connection
            QCon = QFac.createQueueConnection(userName, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return QCon;
    }

    public static TopicConnection getTopicConnection() {
        TopicConnection TCon = null;
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@cloudmove.mypwc.in:1527/xepdb1", "cms", "oracle");
        } catch (SQLException e) {
        }
        try {
            // get connection factory , not going through JNDI here
            TCon =
                AQjmsTopicConnectionFactory.createTopicConnection(conn); //.getTopicConnectionFactory(hostname, oracleService, portno, driver);
            // create connection
        } catch (Exception e) {
            e.printStackTrace();
        }
        return TCon;
    }

    public static void createQueue(String user, String qTable, String queueName) {
        try {
            /* Create Queue Tables */
            System.out.println("Creating Queue Table...");
            QueueConnection QCon = getConnection();
            Session session = QCon.createQueueSession(false, Session.CLIENT_ACKNOWLEDGE);

            AQQueueTableProperty qt_prop;
            AQQueueTable q_table = null;
            AQjmsDestinationProperty dest_prop;
            Queue queue = null;
            qt_prop = new AQQueueTableProperty("SYS.AQ$_JMS_TEXT_MESSAGE");

            q_table = ((AQjmsSession) session).createQueueTable(user, qTable, qt_prop);

            System.out.println("Qtable created");
            dest_prop = new AQjmsDestinationProperty();
            /* create a queue */
            queue = ((AQjmsSession) session).createQueue(q_table, queueName, dest_prop);
            System.out.println("Queue created");
            /* start the queue */
            ((AQjmsDestination) queue).start(session, true, true);

        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }

    public static void sendMessageToTopic(String user, String topicName, String message) {
        Properties info = new Properties();
        info.put("cms", "oracle");

        try {
            TopicConnectionFactory tcf =
                AQjmsFactory.getTopicConnectionFactory("jdbc:oracle:thin:@cloudmove.mypwc.in:1527/xepdb1", info);
            AQjmsConnection TCon = (AQjmsConnection) tcf.createTopicConnection("cms", "oracle");
            AQjmsSession session = (AQjmsSession) TCon.createTopicSession(true, Session.CLIENT_ACKNOWLEDGE);
            TCon.start();
            Topic topic = session.getTopic("cms", topicName);
            AQjmsTopicPublisher tpub = (AQjmsTopicPublisher) session.createPublisher(topic);
            AQjmsTextMessage m = (AQjmsTextMessage) session.createTextMessage();
            m.setText("struggle");
            AQjmsAgent[] rcptList = new AQjmsAgent[1];
            rcptList[0] = new AQjmsAgent("SUBS1", null);
            tpub.publish(m);
            session.commit();
            session.close();
            tpub.close();
            TCon.close();
        } catch (JMSException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        /*
        AQjmsConnection AQjmsConnection
        try {
            TopicConnection TCon = getTopicConnection();
            AQjmsSession session = (AQjmsSession) TCon.createTopicSession(false, Session.CLIENT_ACKNOWLEDGE);
            System.out.println(session.toString());
            Topic topic = session.getTopic(user, topicName);

            AQjmsTopicPublisher tpub = (AQjmsTopicPublisher) session.createPublisher(topic);
            TCon.start();
            TextMessage tMsg = session.createTextMessage(message);
            tpub.publish(tMsg);

            session.close();
            tpub.close();
            TCon.close();

        } catch (JMSException e) {
            e.printStackTrace();
            return;
        }*/
    }

    public static void sendMessage(String user, String queueName, String message) {

        try {
            QueueConnection QCon = getConnection();
            Session session = QCon.createQueueSession(false, Session.CLIENT_ACKNOWLEDGE);
            QCon.start();
            Queue queue = ((AQjmsSession) session).getQueue(user, queueName);
            MessageProducer producer = session.createProducer(queue);
            TextMessage tMsg = session.createTextMessage(message);

            //set properties to msg since axis2 needs this parameters to find the operation
            tMsg.setStringProperty("SOAPAction", "getQuote");
            producer.send(tMsg);
            System.out.println("Sent message = " + tMsg.getText());

            session.close();
            producer.close();
            QCon.close();

        } catch (JMSException e) {
            e.printStackTrace();
            return;
        }
    }

    public static void browseMessage(String user, String queueName) {
        Queue queue;
        try {
            QueueConnection QCon = getConnection();
            Session session = QCon.createQueueSession(false, Session.CLIENT_ACKNOWLEDGE);

            QCon.start();
            queue = ((AQjmsSession) session).getQueue(user, queueName);
            QueueBrowser browser = session.createBrowser(queue);
            Enumeration enu = browser.getEnumeration();
            List list = new ArrayList();
            while (enu.hasMoreElements()) {
                TextMessage message = (TextMessage) enu.nextElement();
                list.add(message.getText());
            }
            for (int i = 0; i < list.size(); i++) {
                System.out.println("Browsed msg " + list.get(i));
            }
            browser.close();
            session.close();
            QCon.close();

        } catch (JMSException e) {
            e.printStackTrace();
        }

    }

    public static void consumeMessage(String user, String queueName) {
        Queue queue;
        try {
            QueueConnection QCon = getConnection();
            Session session = QCon.createQueueSession(false, Session.CLIENT_ACKNOWLEDGE);
            QCon.start();
            queue = ((AQjmsSession) session).getQueue(user, queueName);
            MessageConsumer consumer = session.createConsumer(queue);
            TextMessage msg = (TextMessage) consumer.receive();
            /*
            while (msg.getPropertyNames().hasMoreElements()) {
                System.out.println("MESSAGE RECEIVED " + msg.getPropertyNames().nextElement());
            }
            */
            System.out.println("MESSAGE RECEIVED " + msg.getText());
            JSONParser parser = new JSONParser();
            JSONObject jsonObject = (JSONObject) parser.parse(msg.getText());
            String JDBC_STRING = (String) jsonObject.get("JDBC_STRING");
            String USERNAME = (String) jsonObject.get("USERNAME");
            String PASSWORD = (String) jsonObject.get("PASSWORD");
            //System.out.println(JDBC_STRING);
            consumer.close();
            session.close();
            QCon.close();
        } catch (JMSException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        String userName = "cms";
        String queue = "XXCM_COMMAND_Q";
        String topic = "XXCM_HEART_BEAT_Q";
        String qTable = "XXCM_COMMAND_T";

        //createQueue(userName, qTable, queue);
        //sendMessage(userName, queue, "<user>text</user>");
        //sendMessageToTopic(userName, topic, "<user>text</user>");
        //browseMessage(userName, queue);
        consumeMessage(userName, queue);
        /*
        while (true) {
            consumeMessage(userName, queue);
            
            try {
                Thread.currentThread().sleep(50);
                System.out.println("Next Attempt");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }*/
    }

    /*
    @Override
    public void onMessage(Message message) {

        try {
            AQjmsTextMessage msg = (AQjmsTextMessage) message;
            System.out.println("MESSAGE RECEIVED " + message.getJMSType());
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }*/
}
